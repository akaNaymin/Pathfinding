﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Media;
using aStar;


namespace Pathfinding
{

    public partial class Main : Form
    {

        int xcells = 20; //initial board dimensions
        int ycells = 20;
        Point start;
        Point finish;

        bool reqRedraw = true; //toggle drawing the board (in case the grid is too large, i've set it to 300)
        Grid myGrid; //graphics setup

        PathFinder2 pathfinder;
        List<Point> path = new List<Point>();
        List<string> calcLog = new List<string>(); //run logs to display on map randomization
        Random rng = new Random();

        private bool[,] map;
        private Player myPlayer;
        List<Enemy> enemies = new List<Enemy>();

        public enum Sounds{Collision, Move, GameOver, Win}
        List<SoundPlayer> loadedSounds = new List<SoundPlayer>();
        System.Windows.Media.MediaPlayer musicPlayer = new System.Windows.Media.MediaPlayer();

        #region Properties

        public bool[,] Map
        {
            get
            {
                return map;
            }

            set
            {
                map = value;
            }
        }

        public Player MyPlayer
        {
            get
            {
                return myPlayer;
            }

            set
            {
                myPlayer = value;
            }
        }

        #endregion


        public Main()
        {
            InitializeComponent();
            ResizeRedraw = true;
            DoubleBuffered = true;
        }


        //static functions

        public static int DisPwr(Point p1, Point p2) //distance power
        {
            return ((p1.X - p2.X) * (p1.X - p2.X) + (p1.Y - p2.Y) * (p1.Y - p2.Y));
        } 

        public static bool[,] GenerateRandomMap(int width, int height) //generates random "map" in the specified dimensions and density
        {
            bool[,] grid = new bool[width, height];

            Random rng = new Random();

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    grid[i, j] = (rng.Next(4) % 4 != 0); //4 = the portion of the map blocked, calculated 1/density(4)
                }
            }

            grid[0, 0] = true; //start &finish are always unblocked
            grid[grid.GetLength(0) - 1, grid.GetLength(1) - 1] = true;

            return grid;
        }


        //functions needed to save or load level files

        public void LoadFile() //loads a text file details a game board
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.DefaultExt = ".txt";
            dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension
            dlg.ShowDialog();
            string file = dlg.FileName;

            if (file != "")
            {
                List<Setting> settings = Setting.ReadSettings(file);
                Point _player = new Point(0, 0);
                List<Point> _enemies = new List<Point>();

                foreach (Setting s in settings)
                {
                    switch (s.Name)
                    {
                        case "player":
                            _player.X = Convert.ToInt32(s.Value.Split(',')[0]);
                            _player.Y = Convert.ToInt32(s.Value.Split(',')[1]);
                            break;
                        case "enemy":
                            Point _enemy = new Point(0, 0);
                            _enemy.X = Convert.ToInt32(s.Value.Split(',')[0]);
                            _enemy.Y = Convert.ToInt32(s.Value.Split(',')[1]);
                            _enemies.Add(_enemy);
                            break;
                        case "xcells":
                            this.xcells = Convert.ToInt32(s.Value);
                            break;
                        case "ycells":
                            this.ycells = Convert.ToInt32(s.Value);
                            break;
                        case "finish":
                            this.finish.X = Convert.ToInt32(s.Value.Split(',')[0]);
                            this.finish.Y = Convert.ToInt32(s.Value.Split(',')[1]);
                            break;
                        default:
                            break;
                    }
                }

                bool[,] _map = ReadMap(file, xcells, ycells);
                ResetBoard(_map, _player,_enemies);
            }
        } 

        public void SaveFile() //saves current board to file
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.FileName = "myLevel";
            dlg.DefaultExt = ".txt";
            dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension
            dlg.ShowDialog();
            string file = dlg.FileName;

            if (file != "")
            {
                List<Setting> _s = new List<Setting>();
                _s.Add(new Setting("xcells", this.xcells.ToString()));
                _s.Add(new Setting("ycells", this.ycells.ToString()));
                _s.Add(new Setting("player", MyPlayer.P.X + "," + MyPlayer.P.Y));
                _s.Add(new Setting("finish", finish.X + "," + finish.Y));
                foreach (Enemy e in enemies)
                {
                    _s.Add(new Setting("enemy", e.P.X + "," + e.P.Y));
                }
                Setting.WriteSettings(_s, file);
                WriteMap(file, this.Map);
            }
        }

        public static bool[,] ReadMap(String filename, int width, int height) //reads a character map from file
        {
            bool[,] myMap = new bool[width, height];
            using (StreamReader reader = new StreamReader(filename))
            {
                string line = " ";

                while (line != null)
                {
                    if (line[0] == '*') //skips input until it reaches the map "drawing" character
                        break;
                    line = reader.ReadLine();
                }

                for (int y = 0; y < height; y++)
                {
                    line = reader.ReadLine();
                    for (int x = 0; x < width; x++)
                    {
                        if (line[x].Equals('O'))
                            myMap[x, y] = true;
                        else
                            myMap[x, y] = false;
                    }
                }
            }
            return myMap;
        }

        public static void WriteMap(string filename, bool[,] myMap) //appends the boolean map to the end of the save file
        {
            List<string> map = new List<string>();
            for (int x = 0; x < myMap.GetLength(0); x++)
            {
                string column = "";
                for (int y = 0; y < myMap.GetLength(1); y++)
                {
                    if (myMap[y, x])
                        column += 'O';
                    else
                        column += 'X';
                }
                map.Add(column);
            }

            using (StreamWriter writer = new StreamWriter(filename, true))
            {
                writer.WriteLine("*");
                foreach (string s in map)
                {
                    writer.WriteLine(s);
                }
            }
        }


        //sound related

        public void SoundPlayer(Sounds s) //plays sounds
        {
           
            switch (s)
            {
                case Sounds.Collision:
                    loadedSounds[0].Play();
                    break;
                case Sounds.Move:
                    loadedSounds[1].Play();
                    break;
                case Sounds.GameOver:
                    loadedSounds[2].Play();
                    break;
                case Sounds.Win:
                    loadedSounds[3].Play();
                    break;
                default:
                    break;
            }
        }

        private List<SoundPlayer> LoadSounds() //loads all sound files
        {
            musicPlayer.Open(new Uri(Application.StartupPath + "/Ttrs_-_BgMusic.wav"));
            musicPlayer.MediaEnded += MediaEndedEvent;

            List <SoundPlayer> loaded = new List<SoundPlayer>();
            loaded.Add(new SoundPlayer(Properties.Resources.Ttrs___Land));
            loaded.Add(new SoundPlayer(Properties.Resources.Ttrs___Move));
            loaded.Add(new SoundPlayer(Properties.Resources.Ttrs___GameOver));
            loaded.Add(new SoundPlayer(Properties.Resources.Ttrs___Win));
            return loaded;
        }

        private void MediaEndedEvent(object sender, EventArgs e)
        {
            musicPlayer.Position = TimeSpan.Zero;
            musicPlayer.Play();
        }

        //board management

        public void SetCellsCount(int x, int y) //the grid resize function, normally triggered by filling the pop up form
        {
            xcells = x;
            ycells = y;
            ResetBoard();
        }

        private Rectangle GetDrawRectangle() //the area in which to draw
        {
            Rectangle rect = new Rectangle();
            rect.Size = new Size(this.ClientSize.Height, this.ClientSize.Height);
            rect.Location = new Point((this.ClientSize.Width - this.ClientSize.Height) / 2, 0);
            return rect;
        }

        private void ResetBoard()
        {

            start = new Point(0, 0);
            finish = new Point(xcells - 1, ycells - 1);

            path.Clear();
            while (path.Count == 0) //to prevent a blocked grid from generating
            {
                calcLog.Clear();

                Map = GenerateRandomMap(xcells, ycells);
                calcLog.Add("Grid size: ( " + Map.GetLength(0) + ", " + Map.GetLength(1) + " )");

                System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch(); //to measure time taken
                stopwatch.Restart();

                pathfinder = new PathFinder2(Map, start, finish);
                path = pathfinder.FindPath();
                calcLog.Add("Time taken: " + stopwatch.Elapsed);
            }

            myGrid = new Grid(GetDrawRectangle(), Map.GetLength(0), Map.GetLength(1));

            if (xcells > 300 || ycells > 300) //to avoid drawing overly large grids (often looks like a black screen but takes long to redraw)
            {
                calcLog.Add("Grid may not be visible.");
                reqRedraw = false; //toggle drawing off
            }
            else
                reqRedraw = true; //toggle drawing on

            MyPlayer = new Player(start, this);
            enemies.Clear();
            for(int i = 0; i <= (xcells / 2 - 5); i++) //creates new enemies
            {
                Point ePoint = CreateNewEnemy();
                map[ePoint.X, ePoint.Y] = true;
            }

            this.Invalidate(); //to trigger redrawing of the form

        } //generates a new map, pathfinder and grid

        private void ResetBoard(bool[,] _map, Point _player, List<Point> _enemies) //resets board to loaded file
        {
            path.Clear();
            while (path.Count == 0) //to prevent a blocked grid from generating
            {
                calcLog.Clear();

                Map = _map;
                calcLog.Add("Grid size: ( " + Map.GetLength(0) + ", " + Map.GetLength(1) + " )");

                System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch(); //to measure time taken
                stopwatch.Restart();

                pathfinder = new PathFinder2(Map, _player, finish);
                path = pathfinder.FindPath();
                calcLog.Add("Time taken: " + stopwatch.Elapsed);
            }

            myGrid = new Grid(GetDrawRectangle(), Map.GetLength(0), Map.GetLength(1));

            if (xcells > 300 || ycells > 300) //to avoid drawing overly large grids (often looks like a black screen but takes long to redraw)
            {
                calcLog.Add("Grid may not be visible.");
                reqRedraw = false; //toggle drawing off
            }
            else
                reqRedraw = true; //toggle drawing on

            MyPlayer = new Player(_player, this);

            enemies.Clear();
            foreach(Point p in _enemies) //creates new enemies
            {
                CreateNewEnemy(p);
                map[p.X, p.Y] = true;
            }

            this.Invalidate(); //to trigger redrawing of the form

        }


        //game update

        private Point CreateNewEnemy()
        {
            Point _location = new Point(0, 0);
            while ((DisPwr(_location, MyPlayer.P) <= (MyPlayer.Radius * MyPlayer.Radius)) || //makes sure enemies dont spawn too close to the player
                (DisPwr(_location, new Point(xcells - 1, ycells - 1))) <= (MyPlayer.Radius * MyPlayer.Radius)) //or the finish point
            {
                _location = new Point(rng.Next(xcells), rng.Next(ycells));
            }
            enemies.Add(new Enemy(_location, this));
            return (_location);
        }

        private Point CreateNewEnemy(Point _location)
        {
            enemies.Add(new Enemy(_location, this));
            return (_location);
        }

        private void DrawBoard(Graphics e)
        {
            Pen myPen = new Pen(Color.Black, 1);
            SolidBrush blackBrush = new SolidBrush(Color.Black);
            SolidBrush whiteBrush = new SolidBrush(Color.White);
            SolidBrush blueBrush = new SolidBrush(Color.Blue);
            SolidBrush forestGreenBrush = new SolidBrush(Color.ForestGreen);
            SolidBrush redBrush = new SolidBrush(Color.Red);
            SolidBrush darkRedBrush = new SolidBrush(Color.DarkRed);
            SolidBrush yellowBrush = new SolidBrush(Color.LightYellow);
            SolidBrush lightBlueBrush = new SolidBrush(Color.LightBlue);

            e.Clear(Color.Black);

            if (reqRedraw)
            {
                for (int x = 0; x < Map.GetLength(0); x++)
                {
                    for (int y = 0; y < Map.GetLength(1); y++)
                    {
                        if (Map[x, y])
                        {
                            e.FillRectangle(whiteBrush, myGrid.GetRectangle(x, y));
                            e.DrawRectangle(myPen, myGrid.GetRectangle(x, y));
                        }
                        else
                        {
                            e.FillRectangle(blackBrush, myGrid.GetRectangle(x, y));
                        }
                    }
                }
            }

            foreach (Point p in path)
            {
                e.FillRectangle(yellowBrush, myGrid.GetRectangle(p.X, p.Y));
                e.DrawRectangle(myPen, myGrid.GetRectangle(p.X, p.Y));
            }

            //
            //int linecount = 0;
            //foreach (string l in calcLog)
            //{
            //    e.DrawString(l, new Font("Consolas", 20, FontStyle.Bold), redBrush, new Point(0, this.Size.Height / 2 + linecount * 20));
            //    linecount++;
            //}

            if (reqRedraw)
            {
                List<Point> points = MyPlayer.ShowRange();
                foreach (Point _p in points)
                {
                    if (Map[_p.X, _p.Y])
                    {
                        e.FillRectangle(lightBlueBrush, myGrid.GetRectangle(_p.X, _p.Y));
                        e.DrawRectangle(myPen, myGrid.GetRectangle(_p.X, _p.Y));
                    }
                }

                e.FillRectangle(blueBrush, myGrid.GetRectangle(MyPlayer.P.X, MyPlayer.P.Y));
                e.DrawRectangle(myPen, myGrid.GetRectangle(MyPlayer.P.X, MyPlayer.P.Y));
            }

            e.FillRectangle(forestGreenBrush, myGrid.GetRectangle(finish.X, finish.Y));
            e.DrawRectangle(myPen, myGrid.GetRectangle(finish.X, finish.Y));

            foreach (Enemy enemy in enemies)
            {
                if(enemy.Active)
                    e.FillRectangle(redBrush, myGrid.GetRectangle(enemy.P.X, enemy.P.Y));
                else
                    e.FillRectangle(darkRedBrush, myGrid.GetRectangle(enemy.P.X, enemy.P.Y));
                e.DrawRectangle(myPen, myGrid.GetRectangle(enemy.P.X, enemy.P.Y));
            }

        } //paint event refers here

        private void GameOver() //message displayed on game over
        {
            DialogResult result = MessageBox.Show("Game over. Restart?", "", MessageBoxButtons.YesNo);
            switch (result)
            {
                case DialogResult.Yes:
                    ResetBoard();
                    break;
                case DialogResult.No:
                    this.Close();
                    break;       
                default:
                    break;
            }
        } 

        public void UpdateElements()
        {
            foreach (Enemy e in enemies)
            {
                if (e.P.Equals(MyPlayer.P)) //checks to see if the player moved on an enemy
                {
                    reqRedraw = false;
                    this.Invalidate();
                    SoundPlayer(Sounds.GameOver);
                    GameOver();
                    break;
                }

                e.Move(); //moves

                if (e.IsInRange())
                    e.Detected(MyPlayer.P); //if enemy is in the player's range, return enemy location

                if (e.P.Equals(MyPlayer.P)) //checks to see if the enemy moved on the player
                {
                    reqRedraw = false;
                    this.Invalidate();
                    SoundPlayer(Sounds.GameOver);
                    GameOver();
                    break;
                }

                this.Invalidate(); //forces redraw

                if (MyPlayer.P.Equals(finish)) //winning message
                {
                    this.Invalidate();
                    SoundPlayer(Sounds.Win);
                    MessageBox.Show("You win!", "Game over", MessageBoxButtons.OK);
                    GameOver();
                    break;
                }
            }
        } //moves all enemies each time the player moves

     

        #region Event handlers

        private void Main_Load(object sender, EventArgs e)
        {
            ResetBoard();
            loadedSounds = LoadSounds();
            musicPlayer.Play();
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    MyPlayer.Move(Direction.Up);
                    break;
                case Keys.Right:
                    MyPlayer.Move(Direction.Right);
                    break;
                case Keys.Down:
                    MyPlayer.Move(Direction.Down);
                    break;
                case Keys.Left:
                    MyPlayer.Move(Direction.Left);
                    break;
                case Keys.Escape:
                    this.Close();
                    break;
                default:
                    break;
            }
        }

        private void MainForm_Paint(object sender, PaintEventArgs e)
        {
            DrawBoard(e.Graphics);     
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            myGrid.SetSize(GetDrawRectangle());
        }

        private void MainForm_HelpButtonClicked(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MessageBox.Show("Press right click to view options.", "Help", MessageBoxButtons.OK);
        }

        private void RandomizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetBoard();
        }

        private void ChangeDimensionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SizeInputForm inputForm = new SizeInputForm(this);
            inputForm.Show();
        }

        private void loadFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadFile();
        }

        private void saveBoardToFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void musicOnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (musicPlayer.Position != TimeSpan.Zero)
                musicPlayer.Stop();
            else
                musicPlayer.Play();
        }

        #endregion


    }
}
