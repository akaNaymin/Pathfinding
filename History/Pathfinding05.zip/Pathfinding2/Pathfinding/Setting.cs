﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Pathfinding
{
    public class Setting //Class used to save properties [settings] between runs;
    {

        private string name;
        private string value;

        #region Properties

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string Value
        {
            get
            {
                return value;
            }

            set
            {
                this.value = value;
            }
        }

        #endregion

        public Setting(String name, String value)
        {
            this.Name = name;
            this.Value = value;
        }

        public override String ToString()
        {
            return (Name + "=" + Value);
        }

        public static void WriteSettings(List<Setting> settings, string file) //Writes list of settings to file in the format "NAME=VALUE" (function ToString());
        {
            using (StreamWriter writer = new StreamWriter(file, false))
            {
                foreach( Setting s in settings)
                {
                    writer.WriteLine(s.ToString());
                }
            }
        }

        public static List<Setting> ReadSettings(string file) //Retrieves list of settings from file;
        {
            List<Setting> myList = new List<Setting>();
            using (StreamReader reader = new StreamReader(file))
            {
                string line = reader.ReadLine();
                while (!reader.EndOfStream)
                {
                    if (line[0] == '*') //quits reader when reaches the map "drawing" sign
                        break;
                    if (line[0] != '/')
                    {
                        String sName = line.Split('=')[0];
                        String sValue = line.Split('=')[1];
                        myList.Add(new Setting(sName, sValue));          
                    }
                    line = reader.ReadLine();
                }
            }
            return (myList);
        }
    }
}

/* Example of implementing the settings list retrieved;
* 
        public void runSettings(List<Setting> myList)
        {
            for (int i = 0; i < myList.Count; i++)
            {
                switch (myList[i].Name)
                {
                    case "top":
                        this.Top = Convert.ToInt32(myList[i].Value);
                        break;
                    case "left":
                        this.Left = Convert.ToInt32(myList[i].Value);
                        break;
                    case "isMaximized":
                        if (Convert.ToBoolean(myList[i].Value))
                            this.WindowState = FormWindowState.Maximized;
                        break;
                    * 
                    * 
                    * 
                    default:
                        break;
                }
            }
        }
*/
