﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace DemoPath
{
    public enum Direction { up, right, down, left}

    public class Player
    {
        public Point p;
        public int radius = 4;
        MainForm form;

        public Player(Point location, MainForm form)
        {
            this.p = location;
            this.form = form;
        }

        public void Move(Direction dir)
        {
            switch (dir)
            {
                case Direction.up:
                    if ((p.Y > 0) && form.map[p.X, p.Y - 1])
                        p.Y--;
                    break;
                case Direction.right:
                    if ((p.X < form.map.GetLength(0) - 1) && form.map[p.X+1, p.Y])
                        p.X++;
                    break;
                case Direction.down:
                    if ((p.Y < form.map.GetLength(1) - 1) && form.map[p.X, p.Y + 1])
                        p.Y++;
                    break;
                case Direction.left:
                    if ((p.X > 0) && form.map[p.X - 1, p.Y])
                        p.X--;
                    break;
                default:
                    break;
            }
            form.UpdateElements();
        }

        public List<Point> ShowRange()
        {
            List<Point> points = new List<Point>();
            for (int x = (p.X - this.radius); x <= (p.X + radius ); x++)
            {
                for (int y = (p.Y - radius); y <= (p.Y + radius); y++)
                {
                    if ((x - p.X)*(x - p.X) + (y - p.Y)*(y - p.Y) <= (radius * radius))
                    {
                        if ((x >= 0 && x < form.map.GetLength(0) && y >= 0 && y < form.map.GetLength(1)))
                        {
                            points.Add(new Point(x, y));
                        }
                    }
                }
            }
            return points;
        }

    }
}
