﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Pathfinding;

namespace DemoPath
{
    public class Enemy
    {
        public Point p;
        Point to;
        MainForm form;
        private PathFinder2 pfinder;
        public Queue<Point> path = new Queue<Point>();

        public Enemy(Point position, MainForm form)
        {
            this.p = position;
            this.form = form;
            pfinder = new PathFinder2(form.map, p, p);
        }

        public void Move()
        {
            if(path.Count != 0)
                p = path.Dequeue();
        }

        public void Detected(Point at)
        {
            if (!at.Equals(to))
            {
                to = at;
                pfinder = new PathFinder2(form.map, p, at);
                path = new Queue<Point>(pfinder.FindPath());
                path.Dequeue();
            }
        }

        


        public bool IsInRange()
        {
            int radius = form.myPlayer.radius;
            if ((form.myPlayer.p.X - this.p.X) * (form.myPlayer.p.X - this.p.X) + (form.myPlayer.p.Y - this.p.Y) * (form.myPlayer.p.Y - this.p.Y) <= (radius * radius))
                return true;
            else
                return false;
        }
    }

}
