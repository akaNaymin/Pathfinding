﻿namespace DemoPath
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.windowSizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x800ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x1024ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x1280ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x1366ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x1600ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randomizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeDimensionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.windowSizeToolStripMenuItem,
            this.randomizeToolStripMenuItem,
            this.changeDimensionsToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(215, 92);
            // 
            // windowSizeToolStripMenuItem
            // 
            this.windowSizeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.x800ToolStripMenuItem,
            this.x1024ToolStripMenuItem,
            this.x1280ToolStripMenuItem,
            this.x1366ToolStripMenuItem,
            this.x1600ToolStripMenuItem});
            this.windowSizeToolStripMenuItem.Name = "windowSizeToolStripMenuItem";
            this.windowSizeToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.windowSizeToolStripMenuItem.Text = "Window Size";
            // 
            // x800ToolStripMenuItem
            // 
            this.x800ToolStripMenuItem.Name = "x800ToolStripMenuItem";
            this.x800ToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.x800ToolStripMenuItem.Text = "800x600";
            this.x800ToolStripMenuItem.Click += new System.EventHandler(this.x800ToolStripMenuItem_Click);
            // 
            // x1024ToolStripMenuItem
            // 
            this.x1024ToolStripMenuItem.Name = "x1024ToolStripMenuItem";
            this.x1024ToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.x1024ToolStripMenuItem.Text = "1024x768";
            this.x1024ToolStripMenuItem.Click += new System.EventHandler(this.x1024ToolStripMenuItem_Click);
            // 
            // x1280ToolStripMenuItem
            // 
            this.x1280ToolStripMenuItem.Name = "x1280ToolStripMenuItem";
            this.x1280ToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.x1280ToolStripMenuItem.Text = "1280x720";
            this.x1280ToolStripMenuItem.Click += new System.EventHandler(this.x1280ToolStripMenuItem_Click);
            // 
            // x1366ToolStripMenuItem
            // 
            this.x1366ToolStripMenuItem.Name = "x1366ToolStripMenuItem";
            this.x1366ToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.x1366ToolStripMenuItem.Text = "1366x768";
            this.x1366ToolStripMenuItem.Click += new System.EventHandler(this.x1366ToolStripMenuItem_Click);
            // 
            // x1600ToolStripMenuItem
            // 
            this.x1600ToolStripMenuItem.Name = "x1600ToolStripMenuItem";
            this.x1600ToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.x1600ToolStripMenuItem.Text = "1600x900";
            this.x1600ToolStripMenuItem.Click += new System.EventHandler(this.x1600ToolStripMenuItem_Click);
            // 
            // randomizeToolStripMenuItem
            // 
            this.randomizeToolStripMenuItem.Name = "randomizeToolStripMenuItem";
            this.randomizeToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.randomizeToolStripMenuItem.Text = "Randomize Board";
            this.randomizeToolStripMenuItem.Click += new System.EventHandler(this.randomizeToolStripMenuItem_Click);
            // 
            // changeDimensionsToolStripMenuItem
            // 
            this.changeDimensionsToolStripMenuItem.Name = "changeDimensionsToolStripMenuItem";
            this.changeDimensionsToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.changeDimensionsToolStripMenuItem.Text = "Change Board Dimensions";
            this.changeDimensionsToolStripMenuItem.Click += new System.EventHandler(this.changeDimensionsToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.ContextMenuStrip = this.contextMenuStrip;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.HelpButton = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Text = "Pathfinder Demo";
            this.HelpButtonClicked += new System.ComponentModel.CancelEventHandler(this.Form1_HelpButtonClicked);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem windowSizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x800ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x1024ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x1280ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x1366ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x1600ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem randomizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeDimensionsToolStripMenuItem;
    }
}

