﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DemoPath
{

    public partial class SizeInputForm : Form
    {
        MainForm mainform;
        public SizeInputForm(MainForm mainform)
        {
            InitializeComponent();
            this.mainform = mainform;
        }

        public int gridWidth = 50;
        public int gridHeight = 50;

        int input;

        private bool TestValue(string input)
        {
            int number;
            bool result = Int32.TryParse(input, out number);

            if (result)
                this.input = number;
            else
                return false;
            return true;
                
        }

        private void okButton_Click(object sender, EventArgs e)
        {

            if (TestValue(this.textBoxWidth.Text) && input <= 1000)
            {
                gridWidth = input;

                if (TestValue(this.textBoxHeight.Text) && input <= 1000)
                    gridHeight = input;
                else
                {
                    MessageBox.Show("Error: invalid input. Enter a number between 1 and 1000.", "Error", MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show("Error: invalid input. Enter a number between 1 and 1000.", "Error", MessageBoxButtons.OK);
            }
            mainform.UpdateGridSize(gridWidth, gridHeight);
        }
    }
}
