﻿using System.Drawing;

namespace DemoPath
{

    public enum ScreenSize { x800x600, x1024x768, x1280x720, x1366x768, x1600x900, };

    class Grid  
    {

        public int xcells;
        public int ycells;
        public Rectangle board;

        public Point[,] boardCoord;
        public Size tile_size;

        public Grid(Rectangle board, int xcells, int ycells) //Creats a resizeable grid then maps cells to given coordinates;
        {
            this.xcells = xcells;
            this.ycells = ycells;
            this.board = board;

            boardCoord = new Point[ycells, xcells];
            SetSize(board);
        }

        public static Size ReturnFixedSize(ScreenSize res)
        {
            switch (res)
            {
                case ScreenSize.x800x600:
                    return (new Size(800, 600));
                case ScreenSize.x1024x768:
                    return (new Size(1024, 768));
                case ScreenSize.x1280x720:
                    return (new Size(1280, 720));
                case ScreenSize.x1366x768:
                    return (new Size(1366, 768));
                case ScreenSize.x1600x900:
                    return (new Size(1600, 900));
                default:
                    return (new Size(800, 600));
            }
        }

        public Rectangle GetRectangle(int x, int y)
        {
            return new Rectangle(boardCoord[x, y], tile_size);
        }

        //public Rectangle[,] GetRectangles()
        //{
        //    Rectangle[,] rects = new Rectangle[xcells, ycells];
        //    for (int x = 0; x < xcells; x++)
        //    {
        //        for (int y = 0; y < ycells; y++)
        //        {
        //            rects[x, y] = new Rectangle(boardCoord[x, y], tile_size);
        //        }
        //    }
        //    return rects;
        //}

        public Size GetTileDrawSize() { return (new Size(tile_size.Width + 1, tile_size.Height + 1)); }


        public void SetSize(Rectangle rect) // Resize function;
        {
            this.board = rect;
            tile_size.Width = board.Width / this.xcells;
            tile_size.Height = board.Height / this.ycells;
            CalcBoard();

        }

        private void CalcBoard()
        {
            for (int i = 0; i < xcells; i++)
            {
                for (int j = 0; j < ycells; j++)
                    boardCoord[j, i] = CalcTile(new Point(i, j));
            }
        }

        private Point CalcTile(Point tileCoord)
        {
            Point location = new Point();
            location.X = (tile_size.Width * tileCoord.X) + ( board.Left );
            location.Y = tile_size.Height * tileCoord.Y;
            return location;
        }

    }
}

/*
 * self explainatory I think. coordinates to place objects in a sized grid.
 * there's no need to use real graphics so im still considering if I can get away with a bunch of pictureboxes
*/