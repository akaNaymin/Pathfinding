﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace aStar
{
    public enum NodeState { Closed, Open, Untested } // closed = does not require further check, open = added but a better route may be possible, untested... yeah

    public class Node
    {
        private Node parent; //the node from which this one was reached
        private Point location; //pre-set
        private bool traversable; //pre-set
        private int g; //cost to reach node
        private int h; //estimated cost to reach finish (heuristic cost)
        private int f; //combined G + H or "path cost", the lower the better
        private NodeState state;

        #region Properties

        public Node Parent
        {
            get
            {
                return parent;
            }

            set
            {
                parent = value;
            }
        }

        public Point Location
        {
            get
            {
                return location;
            }

            set
            {
                location = value;
            }
        }

        public bool Traversable
        {
            get
            {
                return traversable;
            }

            set
            {
                traversable = value;
            }
        }

        public int G
        {
            get
            {
                return g;
            }

            set
            {
                g = value;
            }
        }

        public int H
        {
            get
            {
                return h;
            }

            set
            {
                h = value;
            }
        }

        public int F
        {
            get
            {
                return f;
            }

            set
            {
                f = value;
            }
        }

        public NodeState State
        {
            get
            {
                return state;
            }

            set
            {
                state = value;
            }
        }

        #endregion

        public Node(Point location, bool traversable, NodeState state)
        {
            this.Location = location;
            this.Traversable = traversable;
            this.State = state;
        }

        public void SetH(Point fin) //calculates heuristic by the manhattan approach. technically is value is completely UNNECESSARY to reach optimal path but greatly improves process time.
        {                                   // the manhattan (taxicab) approache is named so due to the city's layout:
                                            //diagonal isnt always possible, so the sum of the absolute differences of their coordinations is used.
            int tempH = 0;
            if (fin.X >= this.Location.X)
                tempH += fin.X - this.Location.X;
            else
                tempH += this.Location.X - fin.X;

            if (fin.Y >= this.Location.Y)
                tempH += fin.Y - this.Location.Y;
            else
                tempH += this.Location.Y - fin.Y;

            this.H = tempH*10;
        }

        public void SetF() { this.F = this.G + this.H; }

        public int CalcG(int dir, Node parent)
        {
            switch (dir)
            {
                case 0: case 2: case 4: case 6: //horizontals
                    return (parent.G + 10);
                case 1: case 3: case 5: case 7: //diagonals
                    return (parent.G + 14); // 14 =sqrt(200) rounded to save process time
                default:
                    return 2048;
            }
        }

    }
}
