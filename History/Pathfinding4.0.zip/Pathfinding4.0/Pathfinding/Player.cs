﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Pathfinding
{
    public enum Direction { Up, Right, Down, Left}

    public class Player
    {
        private Point p; //location
        private int radius = 4; //detection radius
        Main form;

        #region Properties

        public Point P
        {
            get
            {
                return p;
            }

            set
            {
                p = value;
            }
        }

        public int Radius
        {
            get
            {
                return radius;
            }

            set
            {
                radius = value;
            }
        }

        #endregion

        public Player(Point location, Main form)
        {
            this.P = location;
            this.form = form;
        }

        public void Move(Direction dir) //checks if the cell is traversable, if so moves in said direction
        {
            switch (dir)
            {
                case Direction.Up:
                    if ((P.Y > 0) && form.Map[P.X, P.Y - 1])
                    {
                        P = new Point(P.X, P.Y - 1);
                        form.SoundPlayer(Main.Sounds.Move);
                    }
                    else
                        form.SoundPlayer(Main.Sounds.Collision);
                    break;
                case Direction.Right:
                    if ((P.X < form.Map.GetLength(0) - 1) && form.Map[P.X + 1, P.Y])
                    {
                        P = new Point(P.X + 1, P.Y);
                        form.SoundPlayer(Main.Sounds.Move);
                    }
                    else
                        form.SoundPlayer(Main.Sounds.Collision);
                    break;
                case Direction.Down:
                    if ((P.Y < form.Map.GetLength(1) - 1) && form.Map[P.X, P.Y + 1])
                    {
                        P = new Point(P.X, P.Y + 1);
                        form.SoundPlayer(Main.Sounds.Move);
                    }
                    else
                        form.SoundPlayer(Main.Sounds.Collision);
                    break;
                case Direction.Left:
                    if ((P.X > 0) && form.Map[P.X - 1, P.Y])
                    {
                        P = new Point(P.X - 1, P.Y);
                        form.SoundPlayer(Main.Sounds.Move);
                    }
                    else
                        form.SoundPlayer(Main.Sounds.Collision);
                    break;
                default:
                    break;
            }
            form.UpdateElements();
        }

        public List<Point> ShowRange()
        {
            List<Point> points = new List<Point>(); //points to color
            for (int x = (P.X - this.Radius); x <= (P.X + Radius ); x++) //2d loop that checks all points in the square that encloses the circle which its center is the player and radius is detection radius
            {
                for (int y = (P.Y - Radius); y <= (P.Y + Radius); y++)
                {
                    if (Main.DisPwr(new Point(x, y), this.P) <= (Radius * Radius)) //if said point is in said circle //&& Main.DisPwr(new Point(x, y), this.P) >= (Radius + 3)
                    {
                        if ((x >= 0 && x < form.Map.GetLength(0) && y >= 0 && y < form.Map.GetLength(1))) //if the point is inside the map
                        {
                            points.Add(new Point(x, y)); //adds to list
                        }
                    }
                }
            }
            return points;
        }

    }
}
