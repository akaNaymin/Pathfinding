﻿using System.Drawing;

namespace Pathfinding
{ 

    class Grid  
    {

        private int xcells;
        private int ycells;
        private Rectangle board; //grid location and size

        private Point[,] boardCoord; //stores individual cells location
        private Size tileSize;

        #region Properties

        public int Xcells
        {
            get
            {
                return xcells;
            }

            set
            {
                xcells = value;
            }
        }

        public int Ycells
        {
            get
            {
                return ycells;
            }

            set
            {
                ycells = value;
            }
        }

        public Rectangle Board
        {
            get
            {
                return board;
            }

            set
            {
                board = value;
            }
        }

        public Point[,] BoardCoord
        {
            get
            {
                return boardCoord;
            }

            set
            {
                boardCoord = value;
            }
        }

        public Size TileSize
        {
            get
            {
                return tileSize;
            }

            set
            {
                tileSize = value;
            }
        }

        #endregion

        public Grid(Rectangle board, int xcells, int ycells) //creats a resizeable grid then maps cells to given coordinates;
        {
            this.Xcells = xcells;
            this.Ycells = ycells;
            this.Board = board;

            BoardCoord = new Point[xcells, ycells];
            SetSize(board);
        }

        public Rectangle GetRectangle(int x, int y)  //gets the specific tile's coord + size as Rectangle
        {
            return new Rectangle(BoardCoord[x, y], TileSize);
        }

        public void SetSize(Rectangle rect) // Resize function;
        {
            this.Board = rect;
            TileSize = new Size(Board.Height / this.Xcells, Board.Height / this.Ycells);   
            CalcBoard();                
        }

        private void CalcBoard()
        {
            for (int i = 0; i < Ycells; i++)
            {
                for (int j = 0; j < Xcells; j++)
                    BoardCoord[i, j] = CalcTile(new Point(i, j));
            }
        }

        private Point CalcTile(Point tileCoord)
        {
            Point location = new Point();
            location.X = (TileSize.Width * tileCoord.X) + ( Board.Left );
            location.Y = TileSize.Height * tileCoord.Y;
            return location;
        }


    }
}
