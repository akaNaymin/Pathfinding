﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
using System.Diagnostics;

namespace pathfinding
{
    class Program
    {
        public static bool[,] readMap(String filename, int width, int height) //reads a character map from file
        {
            bool[,] myMap = new bool[width, height];
            using (StreamReader reader = new StreamReader(filename))
            {
                string line = reader.ReadLine();
                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        if (line[x].Equals('O'))
                            myMap[x, y] = true;
                        else
                            myMap[x, y] = false;
                    }
                    line = reader.ReadLine();
                }
            }
            return myMap;
        }

        public static void DisplayMap(List<Point> path, bool[,] map)
        {
            bool[,] showPath = new bool[map.GetLength(0), map.GetLength(1)];
            foreach (Point p in path)
            {
                showPath[p.X, p.Y] = true;
            }
            for (int i = 0; i < map.GetLength(1); i++)
            {
                for (int j = 0; j < map.GetLength(0); j++)
                {
                    if (showPath[j, i] == true)
                        Console.Write('*');
                    else if (map[j, i] == true)
                        Console.Write('O');
                    else
                        Console.Write('X');
                }
                Console.WriteLine("");
            }
        }

        static bool[,] GenerateRandomGrid(int width, int height)
        {
            bool[,] grid = new bool[width, height];
            Random rng = new Random();

            for(int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    grid[i, j] = (rng.Next(4) % 4 != 0);
                }
            }

            grid[0, 0] = true;
            grid[grid.GetLength(0) - 1, grid.GetLength(1) - 1] = true;

            return grid;
        }

        static void Main(string[] args)
        {

   
         //   bool[,] map = readMap("level1.txt", 12, 10); //file in which the character map is located, currently need to input size manually
            bool[,] map = GenerateRandomGrid(1000, 1000);    

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            PathFinder pathfinder = new PathFinder(map, new Point(0, 0), new Point(map.GetLength(0) - 1, map.GetLength(1) - 1)); //initialize pathfinder
            List<Point> path = pathfinder.FindPath();

            Console.WriteLine("Width = " + map.GetLength(0).ToString() + " Height = " + map.GetLength(1).ToString());
            Console.WriteLine("Time taken to calculate path: " + stopwatch.ElapsedMilliseconds.ToString() + " ms");

            if (path.Count == 0)
                Console.WriteLine("No path was found.");
          //playMap(path, map); //method to see how the path looks (marked with *s)
            
            Console.WriteLine("Hit any key to exit.");
            Console.ReadKey();
        }


    }
}

/* Pathfinding algorithm sources
http://www.policyalmanac.org/games/aStarTutorial.htm
http://blog.two-cats.com/2014/06/a-star-example/
https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm & https://en.wikipedia.org/wiki/A*_search_algorithm
http://theory.stanford.edu/~amitp/GameProgramming/AStarComparison.html
 */

/* C# documentation, case specific solutions
https://msdn.microsoft.com/en-us/library/
http://stackoverflow.com/
*/

/*
 *history log #4
 * now without alterating the iterated list. no idea how the error never showed up before testing on extremely large grids.
 * added methods to test it performance wise - looking pretty good.
 * 
 *history log #3
 * officially works correctly. tried to leave as many notes as possible. now to implement the complete reader.
 * the first issue was progressing only from the fetched list instead of all the open nodes, effectively making it a fancy Best-First-Search.
 * the second one was mis-calculating the G value when checking an already open node.
 * 
 *history log #2
 * got the algorithm to work, except im not really sure whats causing program to output the not-optimal-path (see current output).
 * Program.readMap creates an array based on file name and info that will be displayed above the grid and read before handing the rest. I created this quickly to test inputs easily.
 * the rest of the current Program class is just testing. i think ill work next on reading / writing levels since i've already started.
 * 
 *history log #1
 * what you're looking at is a wip a* pathfinding algorithm which is dijkstra but implements estimation of remaining distance
 * I still have the running function and the recursive search function to implement, finish the GetNearbyNodes function and
 * catch exceptions such as leaving grid aswell as making sure everything is working as intended (rounding corners comes to mind)
 * 
 */
