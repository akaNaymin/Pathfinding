Project by Hagar Zisser

Run Pathfinding\Pathfinding\bin\Release\Pathfinding.exe to start the game.