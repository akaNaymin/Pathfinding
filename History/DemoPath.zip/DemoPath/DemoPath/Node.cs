﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace pathfinding
{

    public enum NodeState { closed, open, untested } // closed = does not require further check, open = added but a better route may be possible, untested... yeah

    public class Node
    {
        public Node parent; //the node from which this one was reached
        public Point location; //pre-set
        public bool traversable; //pre-set
        public int G; //cost to reach node
        public int H; //estimated cost to reach finish (heuristic cost)
        public int F; //combined G + H or "path cost", the lower the better
        public NodeState state;

        public Node(Point location, bool traversable, NodeState state)
        {
            this.location = location;
            this.traversable = traversable;
            this.state = state;
        }

        public void SetH(Point fin) //calculates heuristic by the manhattan approach. technically is value is completely UNNECESSARY to reach optimal path but greatly improves process time.
        {                                   // the manhattan (taxicab) approache is named so due to the city's layout:
                                            //diagonal isnt always possible, so the sum of the absolute differences of their coordinations is used.
            int tempH = 0;
            if (fin.X >= this.location.X)
                tempH += fin.X - this.location.X;
            else
                tempH += this.location.X - fin.X;

            if (fin.Y >= this.location.Y)
                tempH += fin.Y - this.location.Y;
            else
                tempH += this.location.Y - fin.Y;

            this.H = tempH*10;
        }

        public void SetF() { this.F = this.G + this.H; }


        public int CalcG(int dir, Node parent)
        {
            switch (dir)
            {
                case 0: case 2: case 4: case 6: //horizontals
                    return (parent.G + 10);
                case 1: case 3: case 5: case 7: //diagonals
                    return (parent.G + 14); // 14 =sqrt(200) rounded to save process time
                default:
                    return 2048;
            }
        }
    }
}
