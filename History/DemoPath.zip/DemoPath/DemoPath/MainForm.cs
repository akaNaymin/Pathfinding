﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using pathfinding;

namespace DemoPath
{

    public partial class MainForm : Form
    {

        static int xcells = 50;
        static int ycells = 50;

        Grid myGrid;
        PathFinder pathfinder;
        List<Point> path;
        List<string> calcLog = new List<string>();
        bool[,] map = GenerateRandomGrid(xcells, ycells);

        public MainForm()
        {
            InitializeComponent();
            this.ResizeRedraw = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pathfinder = new PathFinder(map, new Point(0, 0), new Point(map.GetLength(0) - 1, map.GetLength(1) - 1));
            path = pathfinder.FindPath();
            myGrid = new Grid(GetActiveRectangle(), map.GetLength(0), map.GetLength(1));
        }

        public static bool[,] GenerateRandomGrid(int width, int height)
        {
            bool[,] grid = new bool[width, height];

            Random rng = new Random();

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    grid[i, j] = (rng.Next(4) % 4 != 0);
                }
            }

            grid[0, 0] = true;
            grid[grid.GetLength(0) - 1, grid.GetLength(1) - 1] = true;

            return grid;
        }

        public void UpdateGridSize(int _x, int _y)
        {
            xcells = _x;
            ycells = _y;

            calcLog.Clear();

            map = GenerateRandomGrid(xcells, ycells);
            calcLog.Add("Grid size: ( " + map.GetLength(0) + ", " + map.GetLength(1) + " )");

            System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();
            stopwatch.Start();

            pathfinder = new PathFinder(map, new Point(0, 0), new Point(map.GetLength(0) - 1, map.GetLength(1) - 1));
            path = pathfinder.FindPath();
            calcLog.Add("Time taken: " + stopwatch.Elapsed);
            if (path.Count == 0)
                calcLog.Add("No path was found.");

            if (_x > 300 && _y > 300)
            {
                calcLog.Add("Grid may not be visible.");
            }
            else
                myGrid = new Grid(GetActiveRectangle(), map.GetLength(0), map.GetLength(1));

            this.Invalidate();
        }

        private Rectangle GetActiveRectangle()
        {
            Rectangle rect = new Rectangle(); ;
            rect.Location = new Point((this.ClientSize.Width - this.ClientSize.Height) / 2, 0);
            rect.Size = new Size(this.ClientSize.Height, this.ClientSize.Height);
            return rect;
        }


        #region Event handlers
 

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

            Graphics graphics = this.CreateGraphics();
            Pen myPen = new Pen(Color.Black, 1);
            SolidBrush blackBrush = new SolidBrush(Color.Black);
            SolidBrush whiteBrush = new SolidBrush(Color.White);
            SolidBrush greenBrush = new SolidBrush(Color.ForestGreen);
            SolidBrush redBrush = new SolidBrush(Color.Red);

            graphics.Clear(Color.Black);

            for (int x = 0; x < map.GetLength(0); x++)
            {
                for (int y = 0; y < map.GetLength(1); y++)
                {
                    if (map[x, y])
                    {
                        graphics.FillRectangle(whiteBrush, myGrid.GetRectangle(x, y));
                        graphics.DrawRectangle(myPen, myGrid.GetRectangle(x, y));
                    }
                    else
                    {
                        graphics.FillRectangle(blackBrush, myGrid.GetRectangle(x, y));
                        graphics.DrawRectangle(myPen, myGrid.GetRectangle(x, y));
                    }
                }
            }
    
            foreach (Point p in path)
            {
                graphics.FillRectangle(greenBrush, new Rectangle(myGrid.boardCoord[p.X, p.Y], myGrid.GetTileDrawSize()));
            }

            int linecount = 0;
            foreach (string l in calcLog)
            {
                graphics.DrawString(l, new Font("Consolas", 20, FontStyle.Bold), redBrush, new Point(0, this.Size.Height /2 + linecount * 20));
                linecount++;
            }
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            myGrid.SetSize(GetActiveRectangle());
        }

        private void Form1_HelpButtonClicked(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MessageBox.Show("Press right click to view options.", "Help", MessageBoxButtons.OK);
        }

        private void randomizeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            calcLog.Clear();

            map = GenerateRandomGrid(xcells, ycells);
            calcLog.Add("Grid size: ( " + map.GetLength(0) + ", " + map.GetLength(1) + " )");

            System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();
            stopwatch.Start();

            pathfinder = new PathFinder(map, new Point(0, 0), new Point(map.GetLength(0) - 1, map.GetLength(1) - 1));
            path = pathfinder.FindPath();
            calcLog.Add("Time taken: " + stopwatch.Elapsed);
            if (path.Count == 0)
                calcLog.Add("No path was found.");
            this.Invalidate();
        }

        #region Resize Menu Strips
        private void x800ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Size = Grid.ReturnFixedSize(ScreenSize.x800x600);
        }

        private void x1024ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Size = Grid.ReturnFixedSize(ScreenSize.x1024x768);
        }

        private void x1280ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Size = Grid.ReturnFixedSize(ScreenSize.x1280x720);
        }

        private void x1366ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Size = Grid.ReturnFixedSize(ScreenSize.x1366x768);
        }

        private void x1600ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Size = Grid.ReturnFixedSize(ScreenSize.x1600x900);
        }
        #endregion

        #endregion

        private void changeDimensionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SizeInputForm inputForm = new SizeInputForm(this);
            inputForm.Show();
        }
    }
}
