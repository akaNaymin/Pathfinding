﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace DemoPath
{
    public enum Direction { up, right, down, left}

    public class Player
    {
        public Point p;
        MainForm form;

        public Player(Point location, MainForm form)
        {
            this.p = location;
            this.form = form;
        }

        public void Move(Direction dir)
        {
            switch (dir)
            {
                case Direction.up:
                    if ((p.Y > 0) && form.map[p.X, p.Y - 1])
                        p.Y--;
                    break;
                case Direction.right:
                    if ((p.X < form.map.GetLength(0) - 1) && form.map[p.X+1, p.Y])
                        p.X++;
                    break;
                case Direction.down:
                    if ((p.Y < form.map.GetLength(1) - 1) && form.map[p.X, p.Y + 1])
                        p.Y++;
                    break;
                case Direction.left:
                    if ((p.X > 0) && form.map[p.X - 1, p.Y])
                        p.X--;
                    break;
                default:
                    break;
            }
            form.UpdateElements();
        }
    }
}
