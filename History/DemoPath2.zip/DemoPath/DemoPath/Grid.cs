﻿using System.Drawing;

namespace DemoPath
{

    public enum ScreenSize { x800x600, x1024x768, x1280x720, x1366x768, x1600x900, }; //set window sizes

    class Grid  
    {

        public int xcells;
        public int ycells;
        public Rectangle board; //grid location and size

        public Point[,] boardCoord; //stores individual cells location
        public Size tile_size;

        public Grid(Rectangle board, int xcells, int ycells) //creats a resizeable grid then maps cells to given coordinates;
        {
            this.xcells = xcells;
            this.ycells = ycells;
            this.board = board;

            boardCoord = new Point[xcells, ycells];
            SetSize(board);
        }

        public static Size ReturnFixedSize(ScreenSize res) //set window size function
        {
            switch (res)
            {
                case ScreenSize.x800x600:
                    return (new Size(800, 600));
                case ScreenSize.x1024x768:
                    return (new Size(1024, 768));
                case ScreenSize.x1280x720:
                    return (new Size(1280, 720));
                case ScreenSize.x1366x768:
                    return (new Size(1366, 768));
                case ScreenSize.x1600x900:
                    return (new Size(1600, 900));
                default:
                    return (new Size(800, 600));
            }
        }  

        public Rectangle GetRectangle(int x, int y)  //gets the specific tile's coord + size as Rectangle
        {
            return new Rectangle(boardCoord[x, y], tile_size);
        }

        public void SetSize(Rectangle rect) // Resize function;
        {
            this.board = rect;
            tile_size.Width = board.Height / this.xcells;
            tile_size.Height = board.Height / this.ycells;
            CalcBoard();                
        }

        private void CalcBoard()
        {
            for (int i = 0; i < ycells; i++)
            {
                for (int j = 0; j < xcells; j++)
                    boardCoord[i, j] = CalcTile(new Point(i, j));
            }
        }

        private Point CalcTile(Point tileCoord)
        {
            Point location = new Point();
            location.X = (tile_size.Width * tileCoord.X) + ( board.Left );
            location.Y = tile_size.Height * tileCoord.Y;
            return location;
        }


    }
}
