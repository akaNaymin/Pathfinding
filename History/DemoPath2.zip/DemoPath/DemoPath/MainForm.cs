﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Pathfinding;

namespace DemoPath
{


    public partial class MainForm : Form
    {

        static int xcells = 20; //initial board dimensions
        static int ycells = 20;
        bool reqRedraw = true; //toggle drawing the board (in case the grid is too large, i've set it to 300)

        Grid myGrid; //graphics setup
        PathFinder2 pathfinder;
        List<Point> path = new List<Point>();
        List<string> calcLog = new List<string>(); //run logs to display on map randomization

        public bool[,] map = GenerateRandomMap(xcells, ycells);
        public Player myPlayer;
        public Enemy enemy1;

        public MainForm()
        {
            InitializeComponent();
            this.ResizeRedraw = true;
            this.DoubleBuffered = true;       
        }

        public static bool[,] GenerateRandomMap(int width, int height) //generates random "map" in the specified dimensions and density
        {
            bool[,] grid = new bool[width, height];

            Random rng = new Random();

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    grid[i, j] = (rng.Next(4) % 4 != 0); //4 = the portion of the map blocked, calculated 1/density(4)
                }
            }

            grid[0, 0] = true; //start &finish are always unblocked
            grid[grid.GetLength(0) - 1, grid.GetLength(1) - 1] = true;

            return grid;
        }

        private void ResetBoard()
        {
            path.Clear();
            while (path.Count == 0) //to prevent a blocked grid from generating
            {
                calcLog.Clear();

                map = GenerateRandomMap(xcells, ycells);
                calcLog.Add("Grid size: ( " + map.GetLength(0) + ", " + map.GetLength(1) + " )");

                System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch(); //to measure time taken
                stopwatch.Restart();

                pathfinder = new PathFinder2(map, new Point(0, 0), new Point(map.GetLength(0) - 1, map.GetLength(1) - 1));
                path = pathfinder.FindPath();
                calcLog.Add("Time taken: " + stopwatch.Elapsed);
            }

            myGrid = new Grid(GetDrawRectangle(), map.GetLength(0), map.GetLength(1));

            if (xcells > 300 || ycells > 300) //to avoid drawing overly large grids (often looks like a black screen but takes long to redraw)
            {
                calcLog.Add("Grid may not be visible.");
                reqRedraw = false; //toggle drawing off
            }
            else
                reqRedraw = true; //toggle drawing on

            this.Invalidate(); //to trigger redrawing of the form

        } //generates a new map, pathfinder and grid

        private void DrawBoard(Graphics e)
        {
            Pen myPen = new Pen(Color.Black, 1);
            SolidBrush blackBrush = new SolidBrush(Color.Black);
            SolidBrush whiteBrush = new SolidBrush(Color.White);
            SolidBrush greenBrush = new SolidBrush(Color.ForestGreen);
            SolidBrush redBrush = new SolidBrush(Color.Red);
            SolidBrush yellowBrush = new SolidBrush(Color.LightYellow);

            e.Clear(Color.Black);

            if (reqRedraw)
            {
                for (int x = 0; x < map.GetLength(0); x++)
                {
                    for (int y = 0; y < map.GetLength(1); y++)
                    {
                        if (map[x, y])
                        {
                            e.FillRectangle(whiteBrush, myGrid.GetRectangle(x, y));
                            e.DrawRectangle(myPen, myGrid.GetRectangle(x, y));
                        }
                        else
                        {
                            e.FillRectangle(blackBrush, myGrid.GetRectangle(x, y));
                        }
                    }
                }
            }

            foreach (Point p in path)
            {
                e.FillRectangle(yellowBrush, myGrid.GetRectangle(p.X, p.Y));
                e.DrawRectangle(myPen, myGrid.GetRectangle(p.X, p.Y));
            }
            //
            //int linecount = 0;
            //foreach (string l in calcLog)
            //{
            //    e.DrawString(l, new Font("Consolas", 20, FontStyle.Bold), redBrush, new Point(0, this.Size.Height / 2 + linecount * 20));
            //    linecount++;
            //}

            e.FillRectangle(greenBrush, myGrid.GetRectangle(myPlayer.p.X, myPlayer.p.Y));
            e.DrawRectangle(myPen, myGrid.GetRectangle(myPlayer.p.X, myPlayer.p.Y));

            //foreach(enemy n in list<enemies)
            e.FillRectangle(redBrush, myGrid.GetRectangle(enemy1.p.X, enemy1.p.Y));
            e.DrawRectangle(myPen, myGrid.GetRectangle(enemy1.p.X, enemy1.p.Y));

        } //paint event refers here

        public void SetGridSize(int x, int y) //the grid resize function, normally triggered by filling the pop up form
        {
            xcells = x;
            ycells = y;
            ResetBoard();
        }

        public void UpdateElements()
        {
            //updates enemies. wip

            //foreach (enemy n in list<enemies>) 

            //if (n.inrange(myplayer.p)) -> n.detected(p);
            enemy1.Detected(new Point(5, 5));

            enemy1.Move();
            if (enemy1.p.Equals(myPlayer.p))
                reqRedraw = false;


            this.Invalidate();
        } //moves all enemies each time the player moves

        private Rectangle GetDrawRectangle() //the area in which to draw
        {
            Rectangle rect = new Rectangle();
            rect.Size = new Size(this.ClientSize.Height, this.ClientSize.Height);
            rect.Location = new Point((this.ClientSize.Width - this.ClientSize.Height) / 2, 0);
            //rect.Size = new Size(this.ClientSize.Height / ycells * xcells, this.ClientSize.Height);
            //rect.Location = new Point((this.ClientSize.Width - this.ClientSize.Height * xcells / ycells) / 2, 0);
            return rect;
        }
     

        #region Event handlers

        private void Form1_Load(object sender, EventArgs e)
        {
            myPlayer = new Player(new Point(0, 0), this);
            enemy1 = new Enemy(new Point(0, 10), this);
            ResetBoard();
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    myPlayer.Move(Direction.up);
                    break;
                case Keys.Right:
                    myPlayer.Move(Direction.right);
                    break;
                case Keys.Down:
                    myPlayer.Move(Direction.down);
                    break;
                case Keys.Left:
                    myPlayer.Move(Direction.left);
                    break;
                case Keys.Escape:
                    this.Close();
                    break;
                default:
                    break;
            }
        }

        private void MainForm_Paint(object sender, PaintEventArgs e)
        {
            DrawBoard(e.Graphics);     
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            myGrid.SetSize(GetDrawRectangle());
        }

        private void MainForm_HelpButtonClicked(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MessageBox.Show("Press right click to view options.", "Help", MessageBoxButtons.OK);
        }

        private void RandomizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetBoard();
        }

        private void ChangeDimensionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SizeInputForm inputForm = new SizeInputForm(this);
            inputForm.Show();
        }

        #region Window Size Menu Strips
        private void x800ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Size = Grid.ReturnFixedSize(ScreenSize.x800x600);
        }

        private void x1024ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Size = Grid.ReturnFixedSize(ScreenSize.x1024x768);
        }

        private void x1280ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Size = Grid.ReturnFixedSize(ScreenSize.x1280x720);
        }

        private void x1366ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Size = Grid.ReturnFixedSize(ScreenSize.x1366x768);
        }

        private void x1600ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Size = Grid.ReturnFixedSize(ScreenSize.x1600x900);
        }
        #endregion

        #endregion

        

        
    }
}
