﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using aStar;

namespace Pathfinding
{
    public class Enemy
    {
        private Point p; //corrent location
        private Point to; //goals
        private Main form;
        private PathFinder2 pfinder;
        private Queue<Point> path = new Queue<Point>();
        private bool active = false;

        #region Properties

        public Point P
        {
            get
            {
                return p;
            }

            set
            {
                p = value;
            }
        }

        public Queue<Point> Path
        {
            get
            {
                return path;
            }

            set
            {
                path = value;
            }
        }

        public bool Active
        {
            get
            {
                return active;
            }

            set
            {
                active = value;
            }
        }

        #endregion

        public Enemy(Point position, Main form) //initalizer
        {
            this.P = position;
            this.form = form;
            pfinder = new PathFinder2(form.Map, P, P);
        }

        public void Move() //moves one step
        {
            if(Path.Count != 0)
                P = Path.Dequeue();
        }

        public void Detected(Point at) //runs when detects the player in Main
        {
            if (!at.Equals(to)) //when the goal is changed
            {
                Active = true;
                to = at; //sets goal to new point
                pfinder = new PathFinder2(form.Map, P, at); //finds new path
                Path = new Queue<Point>(pfinder.FindPath());
                Path.Dequeue();
            }
            else
                Active = false;
        }

        public bool IsInRange() //if the distance between this enemy and the player is smaller than the radius set in Player its considerd in range
        {
            int radius = form.MyPlayer.Radius;
            if (Main.DisPwr(this.P, form.MyPlayer.P) <= (radius * radius))
                return true;
            else
                return false;
        }
    }

}
