﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;

namespace pathfinding
{
    class PathFinder
    {
        bool[,] boolMap;
        Point startPoint;
        Point finishPoint;
        Node[,] nodes;

        public PathFinder(bool[,] boolMap, Point start, Point finish) //initialize a grid(graph) of nodes and resets them
        {
            this.boolMap = boolMap;
            this.startPoint = start;
            this.finishPoint = finish;
            this.nodes = new Node[boolMap.GetLength(0), boolMap.GetLength(1)];

            for (int x = 0; x < boolMap.GetLength(0); x++)
            {
                for (int y = 0; y < boolMap.GetLength(1); y++)
                {
                    this.nodes[x, y] = new Node(new Point(x, y), boolMap[x, y], NodeState.untested);
                }
            }
            this.nodes[startPoint.X, startPoint.Y].SetH(finishPoint);
            this.nodes[startPoint.X, startPoint.Y].G = 0;
            this.nodes[startPoint.X, startPoint.Y].SetF();
            this.nodes[startPoint.X, startPoint.Y].state = NodeState.open;
        }

        public List<Point> FindPath() //initialize the recoursive search function from the start node
        {
            List<Point> path = new List<Point>();

            if (Search(this.nodes[startPoint.X, startPoint.Y], new List<Node>())) //if a path was found, follow it from finish node backwards
            {
                Node curNode = this.nodes[finishPoint.X, finishPoint.Y];
                while (curNode != null)
                {
                    path.Add(curNode.location);
                    curNode = curNode.parent;
                }
            }
            path.Reverse(); //since the returned path is flipped
            return path;
        }


        private bool Search(Node myNode, List<Node> checkList)
        {

            myNode.state = NodeState.closed; //marks current node as checked

            List<Node> newList = new List<Node>(); //to not alter the iterated list <important>
            foreach (Node n in checkList)
                if (n.state != NodeState.closed) //filters closed nodes
                    newList.Add(n);
            newList.AddRange(GetNearbyNodes(myNode)); //adds all neighbors (nodes connected by edges) to the check list
             newList = newList.OrderBy(N => (N.F * 256 + N.H)).ToList(); //orders low -> high based on F value first, H when tied (so best estimated path is first)

            foreach (Node n in newList)
            {
                if (n.location.Equals(this.finishPoint)) //reach destination
                    return true;
                else
                {
                    if (n.state == NodeState.closed) //skips checked nodes
                        continue;
                    
                    if (Search(n, checkList)) //recourses
                        return true;
                }
            }
            return false; //no nodes left to check
        }

        private List<Node> GetNearbyNodes(Node myNode)
        {
            List<Node> nodes = new List<Node>();
            for (int i = 0; i < 8; i++) //read: for each direction
            {
                Node _node = NodeInDir(myNode, i);

                if (_node.state != NodeState.closed && _node.traversable) //skips nodes that are closed or untraversable
                {
                    if (_node.state == NodeState.untested || _node.G > _node.CalcG(i, myNode)) //if untested adds note to checked list, if open checks if the current path is better
                    {
                        _node.parent = myNode;
                        _node.state = NodeState.open;
                        _node.G = _node.CalcG(i, myNode);
                        _node.SetH(finishPoint);
                        _node.SetF();
                        nodes.Add(_node);
                    }
                }
            }
            return nodes;
        }

        private Node NodeInDir(Node myNode, int i)
        {

            //checking bounds, might be better to make it case specific
            Point inBound = myNode.location;
            if (inBound.X <= 0 & (i > 4))
                i = 8;
            if (inBound.X >= boolMap.GetLength(0) - 1 & (i > 0) & (i < 4))
                i = 8;
            if (inBound.Y <= 0 & (i < 2) || (i == 7))
                i = 8;
            if (inBound.Y >= boolMap.GetLength(1) - 1 & (i > 2) & (i < 6))
                i = 8;

            //current conditions don't allow rounding corners at all: to allow it but not crossing through 2 vertical blocks change || to &&, to allow all remove condition
            //directions go from 0-7, 0 being top or north and go clockwise.
            switch (i)
            {
                case 0:
                    return (nodes[myNode.location.X, myNode.location.Y - 1]);
                case 1:
                    if (boolMap[inBound.X, inBound.Y - 1] == false || boolMap[inBound.X + 1, inBound.Y] == false)
                        break;
                    return (nodes[myNode.location.X + 1, myNode.location.Y - 1]);
                case 2:
                    return (nodes[myNode.location.X + 1, myNode.location.Y]);
                case 3:
                    if (boolMap[inBound.X + 1, inBound.Y] == false || boolMap[inBound.X, inBound.Y + 1] == false)
                        break;
                    return (nodes[myNode.location.X + 1, myNode.location.Y + 1]);
                case 4:
                    return (nodes[myNode.location.X, myNode.location.Y + 1]);
                case 5:
                    if (boolMap[inBound.X - 1, inBound.Y] == false || boolMap[inBound.X, inBound.Y + 1] == false)
                        break;
                    return (nodes[myNode.location.X - 1, myNode.location.Y + 1]);
                case 6:
                    return (nodes[myNode.location.X - 1, myNode.location.Y]);
                case 7:
                    if (boolMap[inBound.X, inBound.Y - 1] == false || boolMap[inBound.X - 1, inBound.Y] == false)
                        break;
                    return (nodes[myNode.location.X - 1, myNode.location.Y - 1]);
                default:
                    return myNode;
            }
            return myNode;
        }
    }
}
