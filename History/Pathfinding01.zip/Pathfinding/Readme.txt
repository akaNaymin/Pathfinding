Project by Hagar Zisser

Run Pathfinding\bin\Release\Pathfinding.exe to start the game.