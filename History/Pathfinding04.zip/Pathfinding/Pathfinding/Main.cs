﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using aStar;

namespace Pathfinding
{

    public partial class Main : Form
    {

        int xcells = 20; //initial board dimensions
        int ycells = 20;
        bool reqRedraw = true; //toggle drawing the board (in case the grid is too large, i've set it to 300)

        Grid myGrid; //graphics setup
        PathFinder2 pathfinder;
        List<Point> path = new List<Point>();
        List<string> calcLog = new List<string>(); //run logs to display on map randomization
        Random rng = new Random();

        private bool[,] map;
        private Player myPlayer;
        List<Enemy> enemies = new List<Enemy>();

        #region Properties

        public bool[,] Map
        {
            get
            {
                return map;
            }

            set
            {
                map = value;
            }
        }

        public Player MyPlayer
        {
            get
            {
                return myPlayer;
            }

            set
            {
                myPlayer = value;
            }
        }

        #endregion

        public Main()
        {
            InitializeComponent();
            this.ResizeRedraw = true;
            this.DoubleBuffered = true;
            Map = GenerateRandomMap(xcells, ycells);
        }

        public static int DistancePwr(Point p1, Point p2)
        {
            return ((p1.X - p2.X) * (p1.X - p2.X) + (p1.Y - p2.Y) * (p1.Y - p2.Y));
        }

        public static bool[,] GenerateRandomMap(int width, int height) //generates random "map" in the specified dimensions and density
        {
            bool[,] grid = new bool[width, height];

            Random rng = new Random();

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    grid[i, j] = (rng.Next(4) % 4 != 0); //4 = the portion of the map blocked, calculated 1/density(4)
                }
            }

            grid[0, 0] = true; //start &finish are always unblocked
            grid[grid.GetLength(0) - 1, grid.GetLength(1) - 1] = true;

            return grid;
        }

        private void ResetBoard()
        {
            path.Clear();
            while (path.Count == 0) //to prevent a blocked grid from generating
            {
                calcLog.Clear();

                Map = GenerateRandomMap(xcells, ycells);
                calcLog.Add("Grid size: ( " + Map.GetLength(0) + ", " + Map.GetLength(1) + " )");

                System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch(); //to measure time taken
                stopwatch.Restart();

                pathfinder = new PathFinder2(Map, new Point(0, 0), new Point(Map.GetLength(0) - 1, Map.GetLength(1) - 1));
                path = pathfinder.FindPath();
                calcLog.Add("Time taken: " + stopwatch.Elapsed);
            }

            myGrid = new Grid(GetDrawRectangle(), Map.GetLength(0), Map.GetLength(1));

            if (xcells > 300 || ycells > 300) //to avoid drawing overly large grids (often looks like a black screen but takes long to redraw)
            {
                calcLog.Add("Grid may not be visible.");
                reqRedraw = false; //toggle drawing off
            }
            else
                reqRedraw = true; //toggle drawing on

            MyPlayer = new Player(new Point(0, 0), this);
            enemies.Clear();
            for(int i = 0; i < 5; i++)
            {
                Point ePoint = CreateNewEnemy();
                map[ePoint.X, ePoint.Y] = true;
            }

            this.Invalidate(); //to trigger redrawing of the form

        } //generates a new map, pathfinder and grid

        private Point CreateNewEnemy()
        {
            Point _location = new Point(rng.Next(xcells), rng.Next(ycells));
            enemies.Add(new Enemy(_location, this));
            return (_location);
        }

        private void DrawBoard(Graphics e)
        {
            Pen myPen = new Pen(Color.Black, 1);
            SolidBrush blackBrush = new SolidBrush(Color.Black);
            SolidBrush whiteBrush = new SolidBrush(Color.White);
            SolidBrush greenBrush = new SolidBrush(Color.ForestGreen);
            SolidBrush redBrush = new SolidBrush(Color.Red);
            SolidBrush yellowBrush = new SolidBrush(Color.LightYellow);
            SolidBrush orangeBrush = new SolidBrush(Color.Orange);

            e.Clear(Color.Black);

            if (reqRedraw)
            {
                for (int x = 0; x < Map.GetLength(0); x++)
                {
                    for (int y = 0; y < Map.GetLength(1); y++)
                    {
                        if (Map[x, y])
                        {
                            e.FillRectangle(whiteBrush, myGrid.GetRectangle(x, y));
                            e.DrawRectangle(myPen, myGrid.GetRectangle(x, y));
                        }
                        else
                        {
                            e.FillRectangle(blackBrush, myGrid.GetRectangle(x, y));
                        }
                    }
                }
            }

            foreach (Point p in path)
            {
                e.FillRectangle(yellowBrush, myGrid.GetRectangle(p.X, p.Y));
                e.DrawRectangle(myPen, myGrid.GetRectangle(p.X, p.Y));
            }

            
            //
            //int linecount = 0;
            //foreach (string l in calcLog)
            //{
            //    e.DrawString(l, new Font("Consolas", 20, FontStyle.Bold), redBrush, new Point(0, this.Size.Height / 2 + linecount * 20));
            //    linecount++;
            //}
            if (reqRedraw)
            {
                List<Point> points = MyPlayer.ShowRange();
                foreach (Point _p in points)
                {
                    if (Map[_p.X, _p.Y])
                    {
                        e.FillRectangle(orangeBrush, myGrid.GetRectangle(_p.X, _p.Y));
                        e.DrawRectangle(myPen, myGrid.GetRectangle(_p.X, _p.Y));
                    }
                }

                e.FillRectangle(greenBrush, myGrid.GetRectangle(MyPlayer.P.X, MyPlayer.P.Y));
                e.DrawRectangle(myPen, myGrid.GetRectangle(MyPlayer.P.X, MyPlayer.P.Y));
            }

            foreach (Enemy enemy in enemies)
            {
                e.FillRectangle(redBrush, myGrid.GetRectangle(enemy.P.X, enemy.P.Y));
                e.DrawRectangle(myPen, myGrid.GetRectangle(enemy.P.X, enemy.P.Y));
            }

        } //paint event refers here

        public void SetCellsCount(int x, int y) //the grid resize function, normally triggered by filling the pop up form
        {
            xcells = x;
            ycells = y;
            ResetBoard();
        }

        public void UpdateElements()
        {
            foreach (Enemy e in enemies)
            {
                if (e.P.Equals(MyPlayer.P)) //checks to see if the player moved on an enemy
                    reqRedraw = false;

                e.Move(); //moves

                if (e.IsInRange())
                    e.Detected(MyPlayer.P); //if enemy is in the player's range, return enemy location

                if (e.P.Equals(MyPlayer.P)) //checks to see if an enemy moved on a player
                    reqRedraw = false;
            }

            this.Invalidate(); //forces redraw

            if (MyPlayer.P.Equals(new Point(xcells - 1, ycells - 1))) //winning message
                MessageBox.Show("You win!", "Game over", MessageBoxButtons.OK);

        } //moves all enemies each time the player moves

        private Rectangle GetDrawRectangle() //the area in which to draw
        {
            Rectangle rect = new Rectangle();
            rect.Size = new Size(this.ClientSize.Height, this.ClientSize.Height);
            rect.Location = new Point((this.ClientSize.Width - this.ClientSize.Height) / 2, 0);    
            return rect;
        }
     

        #region Event handlers

        private void Main_Load(object sender, EventArgs e)
        {
            ResetBoard();
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    MyPlayer.Move(Direction.Up);
                    break;
                case Keys.Right:
                    MyPlayer.Move(Direction.Right);
                    break;
                case Keys.Down:
                    MyPlayer.Move(Direction.Down);
                    break;
                case Keys.Left:
                    MyPlayer.Move(Direction.Left);
                    break;
                case Keys.Escape:
                    this.Close();
                    break;
                default:
                    break;
            }
        }

        private void MainForm_Paint(object sender, PaintEventArgs e)
        {
            DrawBoard(e.Graphics);     
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            myGrid.SetSize(GetDrawRectangle());
        }

        private void MainForm_HelpButtonClicked(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MessageBox.Show("Press right click to view options.", "Help", MessageBoxButtons.OK);
        }

        private void RandomizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetBoard();
        }

        private void ChangeDimensionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SizeInputForm inputForm = new SizeInputForm(this);
            inputForm.Show();
        }

        #endregion

        

        
    }
}
